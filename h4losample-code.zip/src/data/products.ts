export const products = [
  {
    id: 'h4lo-tee-black',
    title: 'H4LO Tee – Black',
    image: '/images/h4lo-tee-black.jpg',
    price: '45.00',
    currency: 'USD',
  },
  {
    id: 'h4lo-tee-white',
    title: 'H4LO Tee – White',
    image: '/images/h4lo-tee-white.jpg',
    price: '45.00',
    currency: 'USD',
  },
  {
    id: 'h4lo-hat',
    title: 'H4LO Cap',
    image: '/images/h4lo-hat.jpg',
    price: '35.00',
    currency: 'USD',
  },
];
